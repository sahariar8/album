
@include('frontend.common.header') 
    @yield('slider')
    @yield('promo')
    @yield('brands')
    @yield('images')
    @yield('details')
@include('frontend.common.footer')