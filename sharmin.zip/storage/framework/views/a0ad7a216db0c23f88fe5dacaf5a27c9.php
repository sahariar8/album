
<?php $__env->startSection('images'); ?>
<div class="product-big-title-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="product-bit-title text-center">
                    <h2>Show Special Picture</h2>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="single-product-area" style="min-height: 658px">
    <div class="zigzag-bottom"></div>
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $picture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 col-sm-6">
                <div class="single-product">
                    <div class="product-f-image">
                        <img src="<?php echo e(asset('/')); ?><?php echo e($p->img); ?>" alt="" style="height: 300px; width:260px">
                        <div class="product-hover">
                            <a href="<?php echo e(route('details',$p->id)); ?>" class="view-details-link"><i class="fa fa-link"></i> See details</a>
                        </div>
                    </div>
                    
                    <h2 class="text-primary"><?php echo e($p->title); ?></h2>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master.fmastering', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\s-xampp\htdocs\sharmin\resources\views/frontend/pages/special.blade.php ENDPATH**/ ?>