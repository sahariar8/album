
<?php $__env->startSection('special'); ?>
   <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <h1 class="text-primary py-5 text-center" style="font-family: roboto">Insert Regular Picture</h1>
                <h2 class="text-success text-center"><?php echo e(Session::get('msg')); ?></h2>
                <form action="<?php echo e(route('regular.insert')); ?>" method="post" enctype="multipart/form-data" class="border p-5 rounded">
                    <?php echo csrf_field(); ?>
                    <div class="form-group my-2">
                      <label for="title" class="my-2"><b>Image Title :</b></label>
                      <input type="text" class="form-control" name="title" required>
                    </div>
                    <div class="form-group my-2">
                      <label for="date" class="my-2"><b>Date</b></label>
                      <input type="datetime-local" class="form-control" name="date" required>
                    </div>
                    <div class="form-group my-2">
                      <label for="desc" class="my-2"><b>Image Description</b></label>
                      <input type="text" class="form-control" name="desc" required>
                    </div>
                    <div class="form-group my-2">
                      <label for="date" class="my-2"><b>Image :</b></label>
                      <input type="file" class="form-control" name="rimg" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </form>

            </div>
        </div>
   </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master.bmastering', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\s-xampp\htdocs\sharmin\resources\views/backend/regular/regular.blade.php ENDPATH**/ ?>