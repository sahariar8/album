
<?php $__env->startSection('slider'); ?>
<div class="slider-area" style="width: 60%;">
    <!-- Slider -->
    <div class="block-slider block-slider4">
    
        <ul id="bxslider-home4">
            <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row d-flex justify-content-between">
                <div class="col-md-5">
                    <li>
                        <img src="<?php echo e(asset('/')); ?><?php echo e($s->simg); ?>" alt="Slide" style="width: 100%; height:400px; margin-left:135px; border-radius:5%">
                </div>
            
                <div class="col-md-4 ">
                    <div class="caption-group " style="margin-top: 100px;">
                        <h2 class="caption title text-primary">
                           <?php echo e($s->title); ?>

                        </h2>
                        <h5 class="caption subtitle"><?php echo e($s->desc); ?></h5>
                    </div>
                </li>
                </div>

            </div>
            
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
       
    </div>
    <!-- ./Slider -->
</div> <!-- End slider area -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('promo'); ?>
<div class="promo-area">
    <div class="zigzag-bottom"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-6">
                    <div class="single-promo promo1">
                        <i class="fas fa-heart"></i>
                        <a href="<?php echo e(route('fspecial')); ?>" style="color: white; text-decoration:none"><p>Special</p></a>
                    </div>
            </div>

            <div class="col-md-3 col-sm-6">
                <div class="single-promo promo2">
                    <i class="fa-solid fa-face-smile"></i>
                    <a href="<?php echo e(route('foccasion')); ?>"  style="color: white; text-decoration:none"><p>Occasions</p></a>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="single-promo promo3">
                    <i class="fa-solid fa-calendar-day"></i>
                    <a href="<?php echo e(route('fregular')); ?>"  style="color: white; text-decoration:none"><p>Regular</p></a>
                </div>
            </div>
            <div class="col-md-3 col-sm-6">
                <div class="single-promo promo4">
                    <i class="fa-solid fa-face-laugh-wink"></i>
                    <a href="<?php echo e(route('ftour')); ?>"  style="color: white; text-decoration:none"><p>Tour</p></a>
                </div>
            </div>
        </div>
    </div>
</div> 
<!-- End promo area -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('brands'); ?>
<div class="maincontent-area">
    <div class="zigzag-bottom"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="latest-product">
                    <h2 class="section-title">Latest Picture</h2>
                    <div class="product-carousel">
                       <?php $__currentLoopData = $picture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="single-product">
                            <div class="product-f-image">
                                <img src="<?php echo e(asset('/')); ?><?php echo e($p->img); ?>" alt="" style="height:250px">
                            </div>
                            
                            <h2><?php echo e($p->title); ?></h2>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> 
<!-- End main content area -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('images'); ?>
<div class="product-big-title-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="product-bit-title text-center">
                    <h2>Show All Images</h2>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="single-product-area">
    <div class="zigzag-bottom"></div>
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $picture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 col-sm-6">
                <div class="single-product">
                    <div class="product-f-image">
                        <img src="<?php echo e(asset('/')); ?><?php echo e($p->img); ?>" alt="" style="height: 300px; width:260px">
                    </div>
                    
                    <h2 class="text-primary"><?php echo e($p->title); ?></h2>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
        </div>
    </div>
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $occasion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 col-sm-6">
                <div class="single-product">
                    <div class="product-f-image">
                        <img src="<?php echo e(asset('/')); ?><?php echo e($o->oimg); ?>" alt="" style="height: 300px; width:260px">
                    </div>
                    
                    <h2 class="text-primary"><?php echo e($o->title); ?></h2>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
        </div>
    </div>
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $regular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 col-sm-6">
                <div class="single-product">
                    <div class="product-f-image">
                        <img src="<?php echo e(asset('/')); ?><?php echo e($r->rimg); ?>" alt="" style="height: 300px; width:260px">
                    </div>
                    
                    <h2 class="text-primary"><?php echo e($r->title); ?></h2>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
        </div>
    </div>
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $tour; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 col-sm-6">
                <div class="single-product">
                    <div class="product-f-image">
                        <img src="<?php echo e(asset('/')); ?><?php echo e($t->timg); ?>" alt="" style="height: 300px; width:260px">
                    </div>
                    
                    <h2 class="text-primary"><?php echo e($t->title); ?></h2>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master.fmastering', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\s-xampp\htdocs\sharmin\resources\views/frontend/pages/home.blade.php ENDPATH**/ ?>