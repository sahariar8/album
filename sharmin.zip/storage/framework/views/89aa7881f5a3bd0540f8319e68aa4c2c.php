
<?php $__env->startSection('manage'); ?>
<div class="containre">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <h1 class="text-primary text-center py-5" style="font-family: roboto">Show All Special Picture & Details</h1>
            <h2 class="text-center text-danger"><?php echo e(Session::get('msg')); ?></h2>
            <table class="table table-bordered py-5">
                <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Date & Time</th>
                    <th>Image</th>
                    <th>Action</th>
                </tr>
                <?php $__currentLoopData = $picture; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($p->id); ?></td>
                        <td><?php echo e($p->title); ?></td>
                        <td><textarea name="" id="" cols="auto" rows="auto"><?php echo e($p->desc); ?></textarea></td>
                        <td><?php echo e($p->date); ?></td>
                        <td><img src="<?php echo e(asset('/')); ?><?php echo e($p->img); ?>" alt="" height="70px" width="60px"></td>
                        <td>
                            <a href="<?php echo e(route('edit',$p->id)); ?>" class="btn btn-warning">Edit</a>
                            <a href="<?php echo e(route('destroy',$p->id)); ?>" class="btn btn-danger" onclick="return confirm('Are you Sure to Delete this Picture?')">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master.bmastering', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\s-xampp\htdocs\sharmin\resources\views/backend/pages/manage.blade.php ENDPATH**/ ?>