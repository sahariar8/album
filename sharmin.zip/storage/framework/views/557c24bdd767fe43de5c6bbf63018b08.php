<div class="footer-bottom-area" style="height: 60px">
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-sm-12">
                <div class="copyright">
                    <p style="margin-top:24px">&copy; 2023 Sahariar. All Rights Reserved. <a href="">sahariaralam8@gmail.com</a></p>
                </div>
            </div>
            
            <div class="col-md-4 col-sm-12">
                <div class="footer-card-icon" style="margin-top:10px">
                   <a href=""> <i class="fa-brands fa-square-facebook fa-bounce" style="color: #f1ecec;"></i></a>
                   <a href=""> <i class="fa-brands fa-square-twitter fa-beat-fade" style="color: #e8ecf3;"></i></a>
                   <a href=""> <i class="fa-brands fa-instagram fa-shake" style="color: #e8ecf3;"></i></a>
                   <a href=""><i class="fa-brands fa-linkedin fa-spin" style="color: #e8ecf3;"></i></a>
                </div>
            </div>
        </div>
    </div>
</div> <!-- End footer bottom area -->

<!-- Latest jQuery form server -->
<script src="https://code.jquery.com/jquery.min.js"></script>

<!-- Bootstrap JS form CDN -->
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>

<!-- jQuery sticky menu -->
<script src="<?php echo e(asset('/')); ?>frontend/js/owl.carousel.min.js"></script>
<script src="<?php echo e(asset('/')); ?>frontend/js/jquery.sticky.js"></script>

<!-- jQuery easing -->
<script src="<?php echo e(asset('/')); ?>frontend/js/jquery.easing.1.3.min.js"></script>

<!-- Main Script -->
<script src="<?php echo e(asset('/')); ?>frontend/js/main.js"></script>

<!-- Slider -->
<script type="text/javascript" src="<?php echo e(asset('/')); ?>frontend/js/bxslider.min.js"></script>
<script type="text/javascript" src="<?php echo e(asset('/')); ?>frontend/js/script.slider.js"></script>
</body>
</html><?php /**PATH D:\s-xampp\htdocs\sharmin\resources\views/frontend/common/footer.blade.php ENDPATH**/ ?>