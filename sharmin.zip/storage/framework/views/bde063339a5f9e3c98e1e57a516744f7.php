
<?php $__env->startSection('special'); ?>
   <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <h1 class="text-primary py-5 text-center">Edit Picture & Details</h1>
                <h2 class="text-success text-center"><?php echo e(Session::get('msg')); ?></h2>
                <form action="<?php echo e(route('update',$picture->id)); ?>" method="post" enctype="multipart/form-data" class="border p-5 rounded">
                    <?php echo csrf_field(); ?>
                    <div class="form-group my-2">
                      <label for="title" class="my-2"><b>Image Title :</b></label>
                      <input type="text" class="form-control" name="title" value="<?php echo e($picture->title); ?>">
                    </div>
                    <div class="form-group my-2">
                      <label for="date" class="my-2"><b>Date</b></label>
                      <input type="datetime-local" class="form-control" name="date" value="<?php echo e($picture->date); ?>">
                    </div>
                    <div class="form-group my-2">
                      <label for="desc" class="my-2"><b>Image Description</b></label>
                      <input type="text" class="form-control" name="desc" value="<?php echo e($picture->desc); ?>">
                    </div>
                    <div class="form-group my-2">
                        <label for="img" class="my-2"><b>Existing Image</b></label>
                        <img src="<?php echo e(asset('/')); ?><?php echo e($picture->img); ?>" alt="" height="80px" width="100px">
                    </div>
                    <div class="form-group my-2">
                      <label for="date" class="my-2"><b>Image :</b></label>
                      <input type="file" class="form-control" name="img">
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </form>

            </div>
        </div>
   </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master.bmastering', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\s-xampp\htdocs\sharmin\resources\views/backend/pages/edit.blade.php ENDPATH**/ ?>